// Ashley Lindquist
// 02-04-19
// Pop Sales With Arrays
// Generates JAVPOPSLB.PRT and JAVPOPERB.PRT Reports


import java.io.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;




public class PopSalesArray {
	
	static String   iLastName;
	static String   iFirstName;
	static String   iAddress;
	static String   iCity;
	static String   iState;
	static String[] ArrState = {"IA", "IL", "MI", "MO", "NE", "WI"};
	static double[] ArrDeposit = {1.2, 0.0, 2.4, 0.0, 1.2, 1.2};
	static double   cDeposit;
	static String   oDeposit;
	static String   iZip1, iZip2;
	static int      cZip;
	static String   iPopType;
	static int      cPopType;
	static int[]    ArrPopNum = {01, 02, 03, 04, 05, 06};
	static String[] ArrPopName = {"Coke", "Diet Coke", "Mello Yello", "Cherry Coke", "Diet Cherry Coke", "Sprite"};
	static String   iNumCases;
	static int      cNumCases;
	static String   iTeam;
	static String[] ArrTeam = {"A","B","C","D","E"};
	
	static double   cPrice = 18.71;

	static int      cErrQty = 0;
	static int      cPctrErr = 0;
	static int      cPctr = 0;
	
	static int      i = 0;
	static int      index;
	
	static String[] ArrErrMsg = {"Last Name Required", "First Name Required", "Address Required", "City Required",
							   "State must be IA, IL, MI, MO, NE or WI", "Zip must be numeric",
							   "Pop Type must be numeric. Choose 1 - 6", "Choose more than 0 cases", "Number of Cases must be numeric", 
							   "Team must be A, B, C, D, or E"};
	
	static String   ErrMsg;

	static double[] ArrTotal = new double[5];
	static String   oArrTotal;
	static int[]    ArrNumCases = new int[6];
	static double   cTotal = 0;
	static String   oTotal;
	
	static String   iRecord = "";
	static Scanner  myScanner;
	static PrintWriter  pw;
	static PrintWriter  pwErr;
	static NumberFormat nf;
	static boolean  eof;
	static boolean  valid;
	
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	
	

	public static void main(String[] args) {
		
		
		init();
		
		while (!eof) {	
			validation();
			
			if (valid) {
				calcs();	
				output();
				read();
			}
			else {
				errorPrt();
				read();
			}
		}
		
		closing();
		
		pw.close();
		pwErr.close();

	}
	
	public static void init() {
		
		try {
			myScanner = new Scanner(new File("JAVAPOP.DAT"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		} catch (FileNotFoundException e1) {
			System.out.println("File error");
			System.exit(1);
		}
		
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		try {
			pw = new PrintWriter(new File ("JAVPOPSLB.PRT"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		try {
			pwErr = new PrintWriter(new File ("JAVPOPERB.PRT"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		for(int i = 0; i < 5; i++) {
			ArrTotal[i] = 0;
		}
		
		for(int i = 0; i < 6; i++) {
			ArrNumCases[i] = 0;
		}
		
		
		read();
		
		errHeading();
		
		heading();
	}
	
	public static void validation() {
		
		valid = false;
		
		// LAST NAME
		if (iLastName.trim().isEmpty()) {
			ErrMsg = ArrErrMsg[0];
			return;
		}
	
		// FIRST NAME
		if (iFirstName.trim().isEmpty()) {
			ErrMsg = ArrErrMsg[1];
			return;
		}
	
		// ADDRESS
		if (iAddress.trim().isEmpty()) {
			ErrMsg = ArrErrMsg[2];
			return;
		}
	
		// CITY
		if (iCity.trim().isEmpty()) {
			ErrMsg = ArrErrMsg[3];
			return;
		}
		
		// STATE
		iState = iState.toUpperCase();
		for (i = 0; i < ArrState.length; i++) {
			if (iState.equals(ArrState[i])) {
				index = i;
				break;
			}
		}
		
			if (i == ArrState.length) {
				ErrMsg = ArrErrMsg[4];
				return;
			}
		
		
		// ZIP
		try {
			cZip = Integer.parseInt(iZip1);
			cZip = Integer.parseInt(iZip2);
		}
		catch (Exception e) {
			ErrMsg = ArrErrMsg[5];
			return;
		}
		
		// POP TYPE
		try {
			cPopType = Integer.parseInt(iPopType);
		
				if (cPopType < 0 || cPopType > 6) {
					ErrMsg = ArrErrMsg[6];
					return;
				}
			}
		catch (Exception e) {
			ErrMsg = ArrErrMsg[6];
			return;
		}
		
		// NUM CASES
		try {
			cNumCases = Integer.parseInt(iNumCases);
	
				if(cNumCases < 1) {
					ErrMsg = ArrErrMsg[7];
					return;
				}
			}
		catch (Exception e) {
			ErrMsg = ArrErrMsg[8];
			return;
		}

		// TEAM
		iTeam = iTeam.toUpperCase();
		for (i = 0; i < ArrTeam.length; i++) {
			if (iTeam.equals(ArrTeam[i])) {
				index = i;
				break;
			}
		}
		
			if (i == ArrTeam.length) {
				ErrMsg = ArrErrMsg[9];
				return;
			}
			
		valid = true;
	}
	
	
		
	
	public static void calcs() {
		
		ArrNumCases[cPopType-1] += cNumCases;
		
		for (int i = 0; i < ArrState.length; i++) {
			if (iState.equals(ArrState[i])) {
				cDeposit = cNumCases * ArrDeposit[i];
				cTotal = cPrice * cNumCases + cDeposit;
			}		
		}
		
		for (int i = 0; i < ArrTeam.length; i++) {
			if (iTeam.matches(ArrTeam[i])) {
				ArrTotal[i] += cTotal;
			}
		}
	}
	
	public static void output() {
		
		oDeposit = nf.format(cDeposit);
		oTotal = nf.format(cTotal);
		
		pw.format("%-3s%-17s%-17s%-13s%-5s%-5s%1s%-6s%-16s%-8s%-2s%11s%7s%9s%9s\n\n", "", iLastName, iFirstName, iCity, iState, iZip1, "-", iZip2, ArrPopName[cPopType-1], "", iNumCases, "", oDeposit, "", oTotal);
	}
	
	public static void errorPrt() {
		
		pwErr.format("%-72s%-60s\n", iRecord, ErrMsg);	
		
		cErrQty += 1;
	}
	
	public static void heading() {
		
		cPctr += 1;
		
		pw.format("%-6s%-10s%36s%-28s%44s%-6s%2s\n", "Date:", today.format(dtf), "", "ALBIA SOCCER CLUB FUNDRAISER", "", "Page: ", cPctr);
		pw.format("%-56s%-18s\n", "", "Lindquist Division");
		pw.format("%-60s%-20s\n\n", "", "Sales Report");
		pw.format("%-3s%-17s%-17s%-12s%-18s%-21s%-14s%-17s%-13s\n\n", "", "Last Name", "First Name", "City", "State Zip Code", "Pop Type", "Quantity", "Deposit Amt", "Total Sales");
	}
	
	public static void errHeading() {
		
		cPctrErr += 1;
		
		pwErr.format("%-6s%-10s%36s%-28s%44s%-6s%2s\n", "Date:", today.format(dtf), "", "ALBIA SOCCER CLUB FUNDRAISER", "", "Page: ", cPctrErr);
		pwErr.format("%-56s%-18s\n", "", "Lindquist Division");
		pwErr.format("%-60s%-20s\n\n", "", "Error Report");
		pwErr.format("%-72s%-20s\n\n", "Error Record", "Error Description");
	}
	
	public static void read () {
		
		if (myScanner.hasNext()) {
			iRecord = myScanner.next();
			
			iLastName = iRecord.substring(0,15);	 //file position 1 - 15
			iFirstName = iRecord.substring(15,30);	 //file position 16 - 30
			iAddress = iRecord.substring(30,45);     //file position 31 - 45
			iCity = iRecord.substring(45,55);    //file position 46 - 55
			iState = iRecord.substring(55,57);   //file position 56 - 57
			iZip1 = iRecord.substring(57,62);    //file position 58 - 62
			iZip2 = iRecord.substring(62,66);    //file position 63 - 66
			iPopType = iRecord.substring(66,68);     //file position 67 - 68
			iNumCases = iRecord.substring(68,70);    //file position 69 - 70
			iTeam = iRecord.substring(70,71);    //file position 71
		}
		else {
			eof = true;	//no more records so set end of file to true
		}	
	}
	
	public static void closing () {
		
		grandtotal();
		
		errortotal();
	}
	
	public static void grandtotal() {
		
		heading();
		
		pw.format("%-12s\n\n", "Grand Totals:");
		
		for (int i = 0; i < 4; i+=3) {
			pw.format("%-3s%-17s%-7s%-6s%-17s%-7s%6s%-17s%-13s\n\n", "", ArrPopName[i], ArrNumCases[i], "", ArrPopName[i+1], ArrNumCases[i+1], "", ArrPopName[i+2], ArrNumCases[i+2]);
		}
	
		teamtotal();
	}
	
	public static void teamtotal() {
		
		pw.format("\n%-12s\n\n", "Team Totals:");
		
		for (int i = 0; i < ArrTeam.length; i++) {
			oArrTotal = nf.format(ArrTotal[i]);
			pw.format("%-3s%-2s%-12s\n\n", "", ArrTeam[i], oArrTotal);
		}
	}
	
	public static void errortotal() {
		
		pwErr.format("\n%-13s%-5s", "Total Errors ", cErrQty);
	}
}
