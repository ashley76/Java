// Ashley Lindquist
// 01-28-19
// IHCC Fundraiser
// Generates Subtotal Report


import java.io.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class SubtotalReport {
	
	static String iID;
	static String iGender;
	static String iMajorCode;
	static String oMajor;
	static String iDonation;
	static double cDonation;
	static String oDonation;
	
	static String hMajorBreak;
	static String cMajorBreak;
	
	static int    cSubtotalCtr = 0;
	static int    cGTstudentCtr = 0;
	static double cSubtotalDon;
	static double cGTdonations;
		
	
	static String  iRecord = "";
	static Scanner myScanner;
	static PrintWriter pw;
	static NumberFormat nf;
	static boolean eof;
	
	static String oGender;
	static String oSubtotalDon;
	static String oGTdonations;
	
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	
	
	
	

	public static void main(String[] args) {

		
		init();
		
		while (!eof) {
	
			if (hMajorBreak != cMajorBreak) {
					
				majors();
							
			}		
			
			calcs();
			
			output();
			
			input();
		}
		
		closing();
		
		pw.close();

	}
	
	
	
	
	
	public static void init() {
		
		try {
			myScanner = new Scanner(new File("IHCCFUND.DAT"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		} catch (FileNotFoundException e1) {
			System.out.println("File error");
			System.exit(1);
		}
		
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		try {
			pw = new PrintWriter(new File ("subtotal.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		input();
		
		hMajorBreak = cMajorBreak;
		
		heading();
	}
	
	
	
	
	public static void input() {

		if (myScanner.hasNext()) {
			iRecord = myScanner.next();
			iID = iRecord.substring(0,7);	     //file position 1 - 7
			iGender = iRecord.substring(7,8);	 //file position 8 - 8
			iMajorCode = iRecord.substring(8,10);     //file position 9 -10
			iDonation = iRecord.substring(10,17);    //file position 11 -17
			
		}
		else {
			eof = true;	//no more records so set end of file to true
		}	
		
		cDonation = Double.parseDouble(iDonation);
		
		switch(iMajorCode) {
			case "01":
				cMajorBreak = "1";
				break;
			case "02":
				cMajorBreak = "2";
				break;
			case "03":
				cMajorBreak = "3";
				break;
			case "04":
				cMajorBreak = "4";
				break;
			case "05":
				cMajorBreak = "5";
				break;
			case "06":
				cMajorBreak = "6";
				break;
			case "07":
				cMajorBreak = "7";
				break;
			case "08":
				cMajorBreak = "8";
				break;
			case "09":
				cMajorBreak = "9";
				break;
			case "10":
				cMajorBreak = "10";
				break;
			case "11":
				cMajorBreak = "11";
				break;
			case "12":
				cMajorBreak = "12";
				break;
			case "13":
				cMajorBreak = "13";
				break;
		}
	}
	
	
	

	public static void calcs() {
		
		//cDonation = Double.parseDouble(iDonation);
		
		switch(iMajorCode) {
		
			case "01":
				oMajor = "COMPUTER SOFTWARE DEVELOPMENT";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "02":
				oMajor = "DIESEL POWER SYSTEMS TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "03":
				oMajor = "AUTOMOTIVE TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "04":
				oMajor = "LASER/ELECTRO-OPTICS TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "05":
				oMajor = "ROBOTICS/AUTOMATION TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "06":
				oMajor = "DIGITAL FORENSICS";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";;
				}
				else {
					oGender = "Male";
				}
				break;
			case "07":
				oMajor = "MACHINE TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "08":
				oMajor = "GEOSPATIAL TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "09":
				oMajor = "ADMINISTRATIVE ASSISTANT";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "10":
				oMajor = "ACCOUNTING ASSISTANT";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "11":
				oMajor = "WELDING TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "12":
				oMajor = "AUTOMOTIVE COLLISION TECHNOLOGY";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
			case "13":
				oMajor = "AVAIATION PILOT TRAINING";
				cSubtotalCtr += 1;
				cSubtotalDon += cDonation;
				if (iGender.equals("F")) {
					oGender = "Female";
				}
				else {
					oGender = "Male";
				}
				break;
		}
	}
	
	
	
	public static void heading() {
		
		pw.format("%-10s%22s%20s\n\n", today.format(dtf), "", "IHCC FUNDRAISER");
		pw.format("%37s%-20s\n\n", "", "Subtotal Report");
		pw.format("%-25s%-30s%-37s%-30s\n\n", "ID", "Gender", "Major", "Total Donations");
	}
	
	
	
	
	public static void output() {
		
		oDonation = nf.format(cDonation);
		
		// detail line print out subtotal
		pw.format("%-25s%-30s%-37s%15s\n", iID, oGender, oMajor, oDonation);
	}	
	
	
	
	public static void closing() {
		
		majors();
		grandtotal();
	}
	
	
	
	public static void majors() {
		
		// format donation Subtotal
		oSubtotalDon = nf.format(cSubtotalDon);

		// subtotal like print out subtotal
		pw.format("\n", "");
		pw.format("%-10s%-10s%-35s%-12s%-25s%15s\n\n", "", "Major:", oMajor, "Count:", cSubtotalCtr, oSubtotalDon);
		
		cGTstudentCtr += cSubtotalCtr;
		cGTdonations += cSubtotalDon;
		
		cSubtotalCtr = 0;
		cSubtotalDon = 0;
		
		hMajorBreak = cMajorBreak;
	}
	
	
	public static void grandtotal() {
		
		// format grand totals for subtotal
		oGTdonations = nf.format(cGTdonations);
		
		// grand total line for subtotal
		pw.format("%53s%15s%39s\n", "Grand Totals:", cGTstudentCtr, oGTdonations);
	}
	
}








