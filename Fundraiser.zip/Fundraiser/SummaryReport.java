// Ashley Lindquist
// 01-28-19
// IHCC Fundraiser
// Generates Summary Report


import java.io.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;







public class SummaryReport {
	
	static String iID;
	static String iGender;
	static String iMajorCode;
	static String oMajor;
	static String iDonation;
	static double cDonation;
	
	// summary report variables
	static double cMaleDon = 0;
	static String oMaleDon;
	static int    cMaleCtr = 0;
	static String oMaleCtr;
	static double cFemaleDon = 0;
	static String oFemaleDon;
	static int    cFemaleCtr = 0;
	static String oFemaleCtr;
	static double cInfoDon = 0;
	static String oInfoDon;
	static int    cInfoCtr = 0;
	static String oInfoCtr;
	static double cInfoDonM = 0;
	static String oInfoDonM;
	static int    cInfoCtrM = 0;
	static String oInfoCtrM;
	static double cInfoDonF = 0;
	static String oInfoDonF;
	static int    cInfoCtrF = 0;
	static String oInfoCtrF;
	static double cManuDon = 0;
	static String oManuDon;
	static int    cManuCtr = 0;
	static String oManuCtr;
	static double cManuDonM = 0;
	static String oManuDonM;
	static int    cManuCtrM = 0;
	static String oManuCtrM;
	static double cManuDonF = 0;
	static String oManuDonF;
	static int    cManuCtrF = 0;
	static String oManuCtrF;
	static double cTransDon = 0;
	static String oTransDon;
	static int    cTransCtr = 0;
	static String oTransCtr;
	static double cTransDonM = 0;
	static String oTransDonM;
	static int    cTransCtrM = 0;
	static String oTransCtrM;
	static double cTransDonF = 0;
	static String oTransDonF;
	static int    cTransCtrF = 0;
	static String oTransCtrF;
	static double cOverallDon = 0;
	static String oOverallDon;
	static int    cOverallCtr = 0;
	static String oOverallCtr;
	// summary report variables
	static double cMaleAvg;
	static String oMaleAvg;
	static double cFemaleAvg;
	static String oFemaleAvg;
	static double cInfoAvg;
	static String oInfoAvg;
	static double cManuAvg;
	static String oManuAvg;
	static double cTransAvg;
	static String oTransAvg;
	static double cInfoAvgM;
	static String oInfoAvgM;
	static double cInfoAvgF;
	static String oInfoAvgF;
	static double cManuAvgM;
	static String oManuAvgM;
	static double cManuAvgF;
	static String oManuAvgF;
	static double cTransAvgM;
	static String oTransAvgM;
	static double cTransAvgF;
	static String oTransAvgF;
	static double cOverallAvg;
	static String oOverallAvg;	
	
	static String  iRecord;
	static Scanner myScanner;
	static PrintWriter pw;
	static NumberFormat nf;
	static boolean eof = false;
	
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	
	
	
	
	

	public static void main(String[] args) {
		
		init();
		
		while(!eof) {

			calcs();
		
			input();
			
			average();
			
		}
		
		output();
			
		pw.close();

	}

	
	
	
	
	
	public static void init() {
		
		try {
			myScanner = new Scanner(new File("IHCCFUND.DAT"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		} catch (FileNotFoundException e1) {
			System.out.println("File error");
			System.exit(1);
		}
		
		// set formatter to use as currency format
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		try {
			pw = new PrintWriter(new File ("summary.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		input();
		
		heading();
	}
	
	
	
	public static void input() {
		if (myScanner.hasNext()) {
			iRecord = myScanner.next();
			iID = iRecord.substring(0,7);	     //file position 1 - 7
			iGender = iRecord.substring(7,8);	 //file position 8 - 8
			iMajorCode = iRecord.substring(8,10);     //file position 9 -10
			iDonation = iRecord.substring(10,17);    //file position 11 -17

		}
		else {
			eof = true;	//no more records so set eof to true
		}	
	}
	
	
	public static void calcs() {
		
		cDonation = Double.parseDouble(iDonation);
		
		switch(iMajorCode) {
		
		case "01":
			oMajor = "Information Technology";
			cInfoDon += cDonation;
			cInfoCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cInfoDonF += cDonation;
				cInfoCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cInfoDonM += cDonation;
				cInfoCtrM += 1;
			}
			break;
		case "02":
			oMajor = "Transportation Technology";
			cTransDon += cDonation;
			cTransCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cTransDonF += cDonation;
				cTransCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cTransDonM += cDonation;
				cTransCtrM += 1;
			}
			break;
		case "03":
			oMajor = "Transportation Technology";
			cTransDon += cDonation;
			cTransCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cTransDonF += cDonation;
				cTransCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cTransDonM += cDonation;
				cTransCtrM += 1;
			}
			break;
		case "04":
			oMajor = "Manufacturing Technology";
			cManuDon += cDonation;
			cManuCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cManuDonF += cDonation;
				cManuCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cManuDonM += cDonation;
				cManuCtrM += 1;
			}
			break;
		case "05":
			oMajor = "Manufacturing Technology";
			cManuDon += cDonation;
			cManuCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cManuDonF += cDonation;
				cManuCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cManuDonM += cDonation;
				cManuCtrM += 1;
			}
			break;
		case "06":
			oMajor = "Information Technology";
			cInfoDon += cDonation;
			cInfoCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cInfoDonF += cDonation;
				cInfoCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cInfoDonM += cDonation;
				cInfoCtrM += 1;
			}
			break;
		case "07":
			oMajor = "Manufacturing Technology";
			cManuDon += cDonation;
			cManuCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cManuDonF += cDonation;
				cManuCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cManuDonM += cDonation;
				cManuCtrM += 1;
			}
			break;
		case "08":
			oMajor = "Information Technology";
			cInfoDon += cDonation;
			cInfoCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cInfoDonF += cDonation;
				cInfoCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cInfoDonM += cDonation;
				cInfoCtrM += 1;
			}
			break;
		case "09":
			oMajor = "Information Technology";
			cInfoDon += cDonation;
			cInfoCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cInfoDonF += cDonation;
				cInfoCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cInfoDonM += cDonation;
				cInfoCtrM += 1;
			}
			break;
		case "10":
			oMajor = "Information Technology";
			cInfoDon += cDonation;
			cInfoCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cInfoDonF += cDonation;
				cInfoCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cInfoDonM += cDonation;
				cInfoCtrM += 1;
			}
			break;
		case "11":
			oMajor = "Manufacturing Technology";
			cManuDon += cDonation;
			cManuCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cManuDonF += cDonation;
				cManuCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cManuDonM += cDonation;
				cManuCtrM += 1;
			}
			break;
		case "12":
			oMajor = "Transportation Technology";
			cTransDon += cDonation;
			cTransCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cTransDonF += cDonation;
				cTransCtrF += 1;
			}
			else {
				cFemaleDon += cDonation;
				cMaleCtr += 1;
				cTransDonM += cDonation;
				cTransCtrM += 1;
			}
			break;
		case "13":
			oMajor = "Transportation Technology";
			cTransDon += cDonation;
			cTransCtr += 1;
			if (iGender.equals("F")) {
				cFemaleDon += cDonation;
				cFemaleCtr += 1;
				cTransDonF += cDonation;
				cTransCtrF += 1;
			}
			else {
				cMaleDon += cDonation;
				cMaleCtr += 1;
				cTransDonM += cDonation;
				cTransCtrM += 1;
			}
			break;
		}
	}
	
	public static void average() {
		
		cMaleAvg = cMaleDon / cMaleCtr;
		cFemaleAvg = cFemaleDon / cFemaleCtr;
		cInfoAvg = cInfoDon / cInfoCtr;
		cManuAvg = cManuDon / cManuCtr;
		cTransAvg = cTransDon / cTransCtr;
		cInfoAvgM = cInfoDonM / cInfoCtrM;
		cInfoAvgF = cInfoDonF / cInfoCtrF;
		cManuAvgM = cManuDonM / cManuCtrM;
		cManuAvgF = cManuDonF / cManuCtrF;
		cTransAvgM = cTransDonM / cTransCtrM;
		cTransAvgF = cTransDonF / cTransCtrF;
		
		cOverallDon = cMaleDon + cFemaleDon;
		cOverallCtr = cMaleCtr + cFemaleCtr;
		cOverallAvg = (cMaleDon + cFemaleDon) / 12;
		
	}
	
	
	public static void output() {
		
		// format donation for Summary
		oMaleDon = nf.format(cMaleDon);
		oFemaleDon = nf.format(cFemaleDon);
		oInfoDon = nf.format(cInfoDon);
		oInfoDonM = nf.format(cInfoDonM);
		oInfoDonF = nf.format(cInfoDonF);
		oManuDon = nf.format(cManuDon);
		oManuDonM= nf.format(cManuDonM);
		oManuDonF = nf.format(cManuDonF);
		oTransDon = nf.format(cTransDon);
		oTransDonM = nf.format(cTransDonM);
		oTransDonF = nf.format(cTransDonF);
		
		oOverallDon = nf.format(cOverallDon);
		
		// format average for Summary
		oMaleAvg = nf.format(cMaleAvg);
		oFemaleAvg = nf.format(cFemaleAvg);
		oInfoAvg = nf.format(cInfoAvg);
		oInfoAvgM = nf.format(cInfoAvgM);
		oInfoAvgF = nf.format(cInfoAvgF);
		oManuAvg = nf.format(cManuAvg);
		oManuAvgM= nf.format(cManuAvgM);
		oManuAvgF = nf.format(cManuAvgF);
		oTransAvg = nf.format(cTransAvg);
		oTransAvgM = nf.format(cTransAvgM);
		oTransAvgF = nf.format(cTransAvgF);
		
		oOverallAvg = nf.format(cOverallAvg);
		
				
		pw.format("%-44s%-25s%-23s%7s\n\n", "Group", "Count", "Total", "Average");
		pw.format("%-44s%5s%25s%25s\n", "Male", cMaleCtr, oMaleDon, oMaleAvg);
		pw.format("%-44s%5s%25s%25s\n", "Female", cFemaleCtr, oFemaleDon, oFemaleAvg);
		pw.format("%-44s%5s%25s%25s\n", "Information Technology", cInfoCtr, oInfoDon, oInfoAvg);
		pw.format("%-44s%5s%25s%25s\n", "Manufacturing Technology", cManuCtr, oManuDon, oManuAvg);
		pw.format("%-44s%5s%25s%25s\n", "Transportation Technology", cTransCtr, oTransDon, oTransAvg);
		pw.format("%-44s%5s%25s%25s\n", "Male Information Technology", cInfoCtrM, oTransDonM, oInfoAvgM);
		pw.format("%-44s%5s%25s%25s\n", "Female Information Technoloy", cInfoCtrF, oTransDonF, oInfoAvgF);
		pw.format("%-44s%5s%25s%25s\n", "Male Manufacturing Technology", cManuCtrM, oManuDonM, oManuAvgM);
		pw.format("%-44s%5s%25s%25s\n", "Female Manufacturing Technology", cManuCtrF, oManuDonF, oManuAvgF);
		pw.format("%-44s%5s%25s%25s\n", "Male Transportation Technology", cTransCtrM, oTransDonM, oTransAvgM);
		pw.format("%-44s%5s%25s%25s\n", "Female Transportation Technology", cTransCtrF, oTransDonF, oTransAvgF);
		pw.format("%-44s%5s%25s%25s\n", "Overall", cOverallCtr, oOverallDon, oOverallAvg);
	
		
	}
	
	public static void heading() {
		
		pw.format("%-10s%22s%20s\n\n", today.format(dtf), "", "IHCC FUNDRAISER");
		pw.format("%37s%-20s\n\n", "", "Summary Report");
	}	
}
